const { existsSync, writeJsonSync, readJSONSync } = require("fs-extra");
const moment = require("moment-timezone");
const path = require("path");
const axios = require("axios");
const _ = require("lodash");
const { CustomError } = global.Funcs;

const optionsWriteJSON = {
	spaces: 2,
	EOL: "\n"
};

const messageQueue = global.Funcs.createQueue(async function (task, callback) {
	try {
		const result = await task();
		callback(null, result);
	}
	catch (err) {
		callback(err);
	}
});

const { creatingUserData } = global.Dora.Database;

module.exports = async function (databaseType, userModel, api, fakeGraphql) {
	let Users = [];
	const pathUsersData = path.join(__dirname, "..", "data/usersData.json");

	switch (databaseType) {
		case "mongodb": {
			// delete keys '_id' and '__v' in all users
			Users = (await userModel.find({}).lean()).map(user => _.omit(user, ["_id", "__v"]));
			break;
		}
		case "sqlite": {
			Users = (await userModel.findAll()).map(user => user.get({ plain: true }));
			break;
		}
		case "json": {
			if (!existsSync(pathUsersData))
				writeJsonSync(pathUsersData, [], optionsWriteJSON);
			Users = readJSONSync(pathUsersData);
			break;
		}
	}
	global.DB.allUserData = Users;

	async function save(UserID, userData, mode, path) {
		try {
			let index = _.findIndex(global.DB.allUserData, { UserID });
			if (index === -1 && mode === "update") {
				try {
					await create_(UserID);
					index = _.findIndex(global.DB.allUserData, { UserID });
				}
				catch (err) {
					throw new CustomError({
						name: "USER_NOT_FOUND",
						message: `Can't find user with UserID: ${UserID} in database`
					});
				}
			}

			switch (mode) {
				case "create": {
					switch (databaseType) {
						case "mongodb":
						case "sqlite": {
							let dataCreated = await userModel.create(userData);
							dataCreated = databaseType === "mongodb" ?
								_.omit(dataCreated._doc, ["_id", "__v"]) :
								dataCreated.get({ plain: true });
							global.DB.allUserData.push(dataCreated);
							return _.cloneDeep(dataCreated);
						}
						case "json": {
							const timeCreate = moment.tz().format();
							userData.createdAt = timeCreate;
							userData.updatedAt = timeCreate;
							global.DB.allUserData.push(userData);
							writeJsonSync(pathUsersData, global.DB.allUserData, optionsWriteJSON);
							return _.cloneDeep(userData);
						}
						default: {
							break;
						}
					}
					break;
				}
				case "update": {
					const oldUserData = global.DB.allUserData[index];
					const dataWillChange = {};

					if (Array.isArray(path) && Array.isArray(userData)) {
						path.forEach((p, index) => {
							const key = p.split(".")[0];
							dataWillChange[key] = oldUserData[key];
							_.set(dataWillChange, p, userData[index]);
						});
					}
					else
						if (path && typeof path === "string" || Array.isArray(path)) {
							const key = Array.isArray(path) ? path[0] : path.split(".")[0];
							dataWillChange[key] = oldUserData[key];
							_.set(dataWillChange, path, userData);
						}
						else
							for (const key in userData)
								dataWillChange[key] = userData[key];

					switch (databaseType) {
						case "mongodb": {
							let dataUpdated = await userModel.findOneAndUpdate({ UserID }, dataWillChange, { returnDocument: 'after' });
							dataUpdated = _.omit(dataUpdated._doc, ["_id", "__v"]);
							global.DB.allUserData[index] = dataUpdated;
							return _.cloneDeep(dataUpdated);
						}
						case "sqlite": {
							const user = await userModel.findOne({ where: { UserID } });
							const dataUpdated = (await user.update(dataWillChange)).get({ plain: true });
							global.DB.allUserData[index] = dataUpdated;
							return _.cloneDeep(dataUpdated);
						}
						case "json": {
							dataWillChange.updatedAt = moment.tz().format();
							global.DB.allUserData[index] = {
								...oldUserData,
								...dataWillChange
							};
							writeJsonSync(pathUsersData, global.DB.allUserData, optionsWriteJSON);
							return _.cloneDeep(global.DB.allUserData[index]);
						}
					}
					break;
				}
				case "remove": {
					if (index != -1) {
						global.DB.allUserData.splice(index, 1);
						switch (databaseType) {
							case "mongodb":
								await userModel.deleteOne({ UserID });
								break;
							case "sqlite":
								await userModel.destroy({ where: { UserID } });
								break;
							case "json":
								writeJsonSync(pathUsersData, global.DB.allUserData, optionsWriteJSON);
								break;
						}
					}
					break;
				}
				default: {
					break;
				}
			}
			return null;
		}
		catch (err) {
			throw err;
		}
	}

	async function getName(UserID, checkData = true) {
		if (isNaN(UserID)) {
			throw new CustomError({
				name: "INVALID_USER_ID",
				message: `The first argument (UserID) must be a number, not ${typeof UserID}`
			});
		}
		if (checkData) {
			const userData = global.DB.allUserData.find(u => u.UserID == UserID);
			if (userData)
				return userData.name;
		}
		try {
			const user = await axios.post(`https://www.facebook.com/api/graphql/?q=${`node(${UserID}){name}`}`);
			return user.data[UserID].name;
		}
		catch (error) {
			return null;
		}
	}

	async function getAvatarUrl(UserID) {
      try {
    const url = `https://graph.facebook.com/${UserID}/picture?width=1024&height=1024&access_token=6628568379|c1e620fa708a1d5696fb991c1bde5662`;
    const res = await fetch(url, { redirect: "manual" });
    const pfpUrl = res.headers.get("location") || null;

    if (pfpUrl) {
      return pfpUrl
    } else {
      return "https://i.ibb.co/bBSpr5v/143086968-2856368904622192-1959732218791162458-n.png";
    }

  } catch (err) {
    return "https://i.ibb.co/bBSpr5v/143086968-2856368904622192-1959732218791162458-n.png";
  }
    }

	async function create_(UserID, userInfo) {
		return new Promise(async function (resolve, reject) {
			const findInCreatingData = creatingUserData.find(u => u.UserID == UserID);
			if (findInCreatingData)
				return findInCreatingData.promise;

			const queue = new Promise(async function (resolve_, reject_) {
				try {
					if (global.DB.allUserData.some(u => u.UserID == UserID)) {
						throw new CustomError({
							name: "DATA_ALREADY_EXISTS",
							message: `User with id "${UserID}" already exists in the data`
						});
					}
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not ${typeof UserID}`
						});
					}
					userInfo = userInfo || (await api.GetUserInfo(UserID))[UserID];
					if(!userInfo) return {}
					let userData = {
						UserID,
						name: userInfo?.name || "No Name" ,
						gender: userInfo.gender,
						vanity: userInfo.vanity,
						exp: 0,
						stars: 0,
						money: 0,
						banned: {},
						settings: {},
						data: {}
					};
					userData = await save(UserID, userData, "create");
					resolve_(_.cloneDeep(userData));
				}
				catch (err) {
					reject_(err);
				}
				creatingUserData.splice(creatingUserData.findIndex(u => u.UserID == UserID), 1);
			});
			creatingUserData.push({
				UserID,
				promise: queue
			});
			return resolve(queue);
		});
	}

	async function create(UserID, userInfo) {
		return new Promise(async function (resolve, reject) {
			messageQueue.push(async function () {
				try {
					resolve(await create_(UserID, userInfo));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function refreshInfo(UserID, updateInfoUser) {
		return new Promise(async function (resolve, reject) {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not ${typeof UserID}`
						});
					}
					const infoUser = await get_(UserID);
					updateInfoUser = updateInfoUser || (await api.GetUserInfo(UserID))[UserID];

					const newData = {
						name: updateInfoUser.name,
						vanity: updateInfoUser.vanity,
						gender: updateInfoUser.gender
					};
					let userData = {
						...infoUser,
						...newData
					};

					userData = await save(UserID, userData, "update");
					resolve(_.cloneDeep(userData));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	function getAll(path, defaultValue, query) {
		return new Promise((resolve, reject) => {
			messageQueue.push(function () {
				try {
					let dataReturn = _.cloneDeep(global.DB.allUserData);

					if (query)
						if (typeof query !== "string")
							throw new Error(`The third argument (query) must be a string, not ${typeof query}`);
						else
							dataReturn = dataReturn.map(uData => fakeGraphql(query, uData));

					if (path)
						if (!["string", "object"].includes(typeof path))
							throw new Error(`The first argument (path) must be a string or object, not ${typeof path}`);
						else
							if (typeof path === "string")
								return resolve(dataReturn.map(uData => _.get(uData, path, defaultValue)));
							else
								return resolve(dataReturn.map(uData => _.times(path.length, i => _.get(uData, path[i], defaultValue[i]))));

					return resolve(dataReturn);
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function get_(UserID, path, defaultValue, query) {
		return new Promise(async (resolve, reject) => {
			try {
				if (isNaN(UserID)) {
					throw new CustomError({
						name: "INVALID_USER_ID",
						message: `The first argument (UserID) must be a number, not ${typeof UserID}`
					});
				}
				let userData;

				const index = global.DB.allUserData.findIndex(u => u.UserID == UserID);
				if (index === -1)
					userData = await create_(UserID);
				else
					userData = global.DB.allUserData[index];

				if (query)
					if (typeof query !== "string")
						throw new Error(`The fourth argument (query) must be a string, not ${typeof query}`);
					else
						userData = fakeGraphql(query, userData);

				if (path)
					if (!["string", "array"].includes(typeof path))
						throw new Error(`The second argument (path) must be a string or array, not ${typeof path}`);
					else
						if (typeof path === "string")
							return resolve(_.cloneDeep(_.get(userData, path, defaultValue)));
						else
							return resolve(_.cloneDeep(_.times(path.length, i => _.get(userData, path[i], defaultValue[i]))));

				return resolve(_.cloneDeep(userData));
			}
			catch (err) {
				reject(err);
			}
		});
	}

	async function get(UserID, path, defaultValue, query) {
		return new Promise((resolve, reject) => {
			messageQueue.push(async function () {
				try {
					resolve(await get_(UserID, path, defaultValue, query));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function set(UserID, updateData, path, query) {
		return new Promise((resolve, reject) => {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not ${typeof UserID}`
						});
					}

					if (!path && (typeof updateData != "object" || typeof updateData == "object" && Array.isArray(updateData)))
						throw new Error(`The second argument (updateData) must be an object, not ${typeof updateData}`);

					const userData = await save(UserID, updateData, "update", path);
					if (query)
						if (typeof query !== "string")
							throw new Error(`The fourth argument (query) must be a string, not ${typeof query}`);
						else
							return resolve(_.cloneDeep(fakeGraphql(query, userData)));

					return resolve(_.cloneDeep(userData));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function deleteKey(UserID, path, query) {
		return new Promise(async function (resolve, reject) {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not a ${typeof UserID}`
						});
					}
					if (typeof path !== "string")
						throw new Error(`The second argument (path) must be a string, not a ${typeof path}`);
					const spitPath = path.split(".");
					if (spitPath.length == 1)
						throw new Error(`Can't delete key "${path}" because it's a root key`);
					const parent = spitPath.slice(0, spitPath.length - 1).join(".");
					const parentData = await get_(UserID, parent);
					if (!parentData)
						throw new Error(`Can't find key "${parent}" in user with UserID: ${UserID}`);

					_.unset(parentData, spitPath[spitPath.length - 1]);
					const setData = await save(UserID, parentData, "update", parent);
					if (query)
						if (typeof query !== "string")
							throw new Error(`The fourth argument (query) must be a string, not a ${typeof query}`);
						else
							return resolve(_.cloneDeep(fakeGraphql(query, setData)));
					return resolve(_.cloneDeep(setData));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function getMoney(UserID) {
		return new Promise((resolve, reject) => {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not ${typeof UserID}`
						});
					}
					const money = await get_(UserID, "money");
					resolve(money);
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function getStars(UserID) {
		return new Promise((resolve, reject) => {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not ${typeof UserID}`
						});
					}
					const stars = await get_(UserID, "stars");
					resolve(stars);
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function getExp(UserID) {
		return new Promise((resolve, reject) => {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not ${typeof UserID}`
						});
					}
					const exp = await get_(UserID, "exp");
					resolve(exp);
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}
	async function addExp(UserID, exp, query) {
		return new Promise((resolve, reject) => {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not ${typeof UserID}`
						});
					}
					if (isNaN(exp)) {
						throw new CustomError({
							name: "INVALID_EXP",
							message: `The second argument (exp) must be a number, not ${typeof exp}`
						});
					}
					if (!global.DB.allUserData.some(u => u.UserID == UserID))
						await create_(UserID);
					const currentExp = await get_(UserID, "exp");
					const newExp = currentExp + exp;
					const userData = await save(UserID, newExp, "update", "exp");
					if (query)
						if (typeof query !== "string")
							throw new Error(`The third argument (query) must be a string, not ${typeof query}`);
						else
							return resolve(_.cloneDeep(fakeGraphql(query, userData)));

					return resolve(_.cloneDeep(userData));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}
	async function addMoney(UserID, money, query) {
		return new Promise((resolve, reject) => {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not ${typeof UserID}`
						});
					}
					if (isNaN(money)) {
						throw new CustomError({
							name: "INVALID_MONEY",
							message: `The second argument (money) must be a number, not ${typeof money}`
						});
					}
					if (!global.DB.allUserData.some(u => u.UserID == UserID))
						await create_(UserID);
					const currentMoney = await get_(UserID, "money");
					const newMoney = currentMoney + money;
					const userData = await save(UserID, newMoney, "update", "money");
					if (query)
						if (typeof query !== "string")
							throw new Error(`The third argument (query) must be a string, not ${typeof query}`);
						else
							return resolve(_.cloneDeep(fakeGraphql(query, userData)));

					return resolve(_.cloneDeep(userData));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function addStars(UserID, stars, query) {
		return new Promise((resolve, reject) => {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not ${typeof UserID}`
						});
					}
					if (isNaN(stars)) {
						throw new CustomError({
							name: "INVALID_STARS",
							message: `The second argument (stars) must be a number, not ${typeof stars}`
						});
					}
					if (!global.DB.allUserData.some(u => u.UserID == UserID))
						await create_(UserID);
					const currentStars = await get_(UserID, "stars");
					const newStars = currentStars + stars;
					const userData = await save(UserID, newStars, "update", "stars");
					if (query)
						if (typeof query !== "string")
							throw new Error(`The third argument (query) must be a string, not ${typeof query}`);
						else
							return resolve(_.cloneDeep(fakeGraphql(query, userData)));

					return resolve(_.cloneDeep(userData));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function subtractMoney(UserID, money, query) {
		return new Promise((resolve, reject) => {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not ${typeof UserID}`
						});
					}
					if (isNaN(money)) {
						throw new CustomError({
							name: "INVALID_MONEY",
							message: `The second argument (money) must be a number, not ${typeof money}`
						});
					}
					if (!global.DB.allUserData.some(u => u.UserID == UserID))
						await create_(UserID);
					const currentMoney = await get_(UserID, "money");
					const newMoney = currentMoney - money;
					const userData = await save(UserID, newMoney, "update", "money");
					if (query)
						if (typeof query !== "string")
							throw new Error(`The third argument (query) must be a string, not ${typeof query}`);
						else
							return resolve(_.cloneDeep(fakeGraphql(query, userData)));
					return resolve(_.cloneDeep(userData));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function subtractExp(UserID, exp, query) {
		return new Promise((resolve, reject) => {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not ${typeof UserID}`
						});
					}
					if (isNaN(exp)) {
						throw new CustomError({
							name: "INVALID_EXP",
							message: `The second argument (money) must be a number, not ${typeof money}`
						});
					}
					if (!global.DB.allUserData.some(u => u.UserID == UserID))
						await create_(UserID);
					const currentExp = await get_(UserID, "exp");
					const newExp = currentExp - exp;
					const userData = await save(UserID, newExp, "update", "exp");
					if (query)
						if (typeof query !== "string")
							throw new Error(`The third argument (query) must be a string, not ${typeof query}`);
						else
							return resolve(_.cloneDeep(fakeGraphql(query, userData)));
					return resolve(_.cloneDeep(userData));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

     async function subtractStars(UserID, stars, query) {
		return new Promise((resolve, reject) => {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						throw new CustomError({
							name: "INVALID_USER_ID",
							message: `The first argument (UserID) must be a number, not ${typeof UserID}`
						});
					}
					if (isNaN(stars)) {
						throw new CustomError({
							name: "INVALID_STARS",
							message: `The second argument (stars) must be a number, not ${typeof stars}`
						});
					}
					if (!global.DB.allUserData.some(u => u.UserID == UserID))
						await create_(UserID);
					const currentStars = await get_(UserID, "stars");
					const newStars = currentStars - stars;
					const userData = await save(UserID, newStars, "update", "stars");
					if (query)
						if (typeof query !== "string")
							throw new Error(`The third argument (query) must be a string, not ${typeof query}`);
						else
							return resolve(_.cloneDeep(fakeGraphql(query, userData)));
					return resolve(_.cloneDeep(userData));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}
	async function remove(UserID) {
		return new Promise((resolve, reject) => {
			messageQueue.push(async function () {
				try {
					if (isNaN(UserID)) {
						const error = new Error(`The first argument (UserID) must be a number, not ${typeof UserID}`);
						error.name = "INVALID_USER_ID";
						reject(error);
					}
					await save(UserID, { UserID }, "remove");
					return resolve(true);
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	return {
		existsSync: function existsSync(UserID) {
			return global.DB.allUserData.some(u => u.UserID == UserID);
		},
		getName,
		getAvatarUrl,
		create,
		refreshInfo,
		getAll,
		get,
		set,
		deleteKey,
		subtractStars,
		addStars,
		getStars,
		getExp,
		addExp,
		subtractExp,
		getMoney,
		addMoney,
		subtractMoney,
		remove
	};
};