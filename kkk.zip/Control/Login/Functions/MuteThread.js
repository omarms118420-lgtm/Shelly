const utils = require('../Funcs.js');

  
module.exports = function (FcaData, Client, Context) {
	
	return function muteThread(ThreadID, muteSeconds, callback) {
		let resolveFunc = function () { };
		let rejectFunc = function () { };
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});

		if (!callback) {
			callback = function (err, friendList) {
				if (err) {
					return rejectFunc(err);
				}
				resolveFunc(friendList);
			};
		}

		const form = {
			thread_fbid: ThreadID,
			mute_settings: muteSeconds
		};

		FcaData
			.post(
				"https://www.facebook.com/ajax/mercury/change_mute_thread.php",
				Context.jar,
				form
			)
			.then(utils.saveCookies(Context.jar))
			.then(utils.parseAndCheckLogin(Context, FcaData))
			.then(function (resData) {
				if (resData.error) {
					throw resData;
				}

				return callback();
			})
			.catch(function (err) {
				return callback(err);
			});

		return returnPromise;
	};
};
