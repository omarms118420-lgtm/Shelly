"use strict";

const utils = require('../Funcs.js');


module.exports = function (FcaData, Client, Context) {
	return function handleFriendRequest(userID, accept, callback) {
		if (utils.getType(accept) !== "Boolean") {
			throw {
				error: "Please pass a boolean as a second argument."
			};
		}

		let resolveFunc = function () { };
		let rejectFunc = function () { };
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});

		if (!callback) {
			callback = function (err, friendList) {
				if (err) {
					return rejectFunc(err);
				}
				resolveFunc(friendList);
			};
		}

		const form = {
			viewer_id: Context.i_userID || Context.userID,
			"frefs[0]": "jwl",
			floc: "friend_center_requests",
			ref: "/reqs.php",
			action: (accept ? "confirm" : "reject")
		};

		FcaData
			.post(
				"https://www.facebook.com/requests/friends/ajax/",
				Context.jar,
				form
			)
			.then(utils.parseAndCheckLogin(Context, FcaData))
			.then(function (resData) {
				if (resData.payload.err) {
					throw {
						err: resData.payload.err
					};
				}

				return callback();
			})
			.catch(function (err) {
				return callback(err);
			});

		return returnPromise;
	};
};
