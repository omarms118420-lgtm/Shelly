const utils = require('../Funcs.js');


module.exports = function (FcaData, Client, Context) {
	return function handleMessageRequest(ThreadID, accept, callback) {
		if (utils.getType(accept) !== "Boolean") {
			throw {
				error: "Please pass a boolean as a second argument."
			};
		}

		let resolveFunc = function () { };
		let rejectFunc = function () { };
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});

		if (!callback) {
			callback = function (err, friendList) {
				if (err) {
					return rejectFunc(err);
				}
				resolveFunc(friendList);
			};
		}

		const form = {
			client: "mercury"
		};

		if (utils.getType(ThreadID) !== "Array") {
			ThreadID = [ThreadID];
		}

		const messageBox = accept ? "inbox" : "other";

		for (let i = 0; i < ThreadID.length; i++) {
			form[messageBox + "[" + i + "]"] = ThreadID[i];
		}

		FcaData
			.post(
				"https://www.facebook.com/ajax/mercury/move_thread.php",
				Context.jar,
				form
			)
			.then(utils.parseAndCheckLogin(Context, FcaData))
			.then(function (resData) {
				if (resData.error) {
					throw resData;
				}

				return callback();
			})
			.catch(function (err) {
				return callback(err);
			});

		return returnPromise;
	};
};
