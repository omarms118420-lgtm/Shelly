const utils = require('../Funcs.js');


module.exports = function (FcaData, Client, Context) {
	return function MarkDelivered(ThreadID, MessageID, callback) {
		let resolveFunc = function () { };
		let rejectFunc = function () { };
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});

		if (!callback) {
			callback = function (err, friendList) {
				if (err) {
					return rejectFunc(err);
				}
				resolveFunc(friendList);
			};
		}

		if (!ThreadID || !MessageID) {
			return callback("Error: MessageID or ThreadID is not defined");
		}

		const form = {};

		form["message_ids[0]"] = MessageID;
		form["thread_ids[" + ThreadID + "][0]"] = MessageID;

		FcaData
			.post(
				"https://www.facebook.com/ajax/mercury/delivery_receipts.php",
				Context.jar,
				form
			)
			.then(utils.saveCookies(Context.jar))
			.then(utils.parseAndCheckLogin(Context, FcaData))
			.then(function (resData) {
				if (resData.error) {
					throw resData;
				}

				return callback();
			})
			.catch(function (err) {
				if (utils.getType(err) == "Object" && err.error === "Not logged in.") {
					Context.loggedIn = false;
				}
				return callback(err);
			});

		return returnPromise;
	};
};
