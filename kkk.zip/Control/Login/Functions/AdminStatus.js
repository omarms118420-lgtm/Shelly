const utils = require('../Funcs.js')
const { generateOfflineThreadingID } = utils;
function isCallable(func) {
	try {
	  Reflect.apply(func, null, []);
	  return true;
	} catch (error) {
	  return false;
	}
  }
  
  module.exports = function (FcaData, Client, Context) {
	return async function changeAdminStatus(threadKey, contactID, isAdmin, callback) {
	  if (!Context.mqttClient) {
		throw new Error("Not connected to MQTT");
	  }
  
	  Context.wsReqNumber += 1;
	  Context.wsTaskNumber += 1;
  
	  const label = "25";
	  const queueName = "admin_status";
  
	  const taskPayload = {
		thread_key: threadKey,
		contact_id: contactID,
		is_admin: isAdmin,
	  };
  
	  const payload = JSON.stringify(taskPayload);
	  const version = "9305733849522974";
	  const epoch = parseInt(generateOfflineThreadingID());
  
	
	  const task = {
		failure_count: null,
		label: label,
		payload: payload,
		queue_name: queueName,
		task_id: Context.wsTaskNumber,
	  };
  
	  const content = {
		app_id: "2220391788200892",
		payload: JSON.stringify({
		  tasks: [task],
		  epoch_id: epoch,
		  version_id: version,
		}),
		request_id: Context.wsReqNumber,
		type: 3,
	  };
  
	  if (isCallable(callback)) { }
  
	
	  Context.mqttClient.publish(
		"/ls_req",
		JSON.stringify(content),
		{ qos: 1, retain: false }
	  );
	};
  };
  