const utils = require('../Funcs.js');


module.exports = function (FcaData, Client, Context) {
	return function unfriend(userID, callback) {
		let resolveFunc = function () { };
		let rejectFunc = function () { };
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});

		if (!callback) {
			callback = function (err, friendList) {
				if (err) {
					return rejectFunc(err);
				}
				resolveFunc(friendList);
			};
		}

		const form = {
			uid: userID,
			unref: "bd_friends_tab",
			floc: "friends_tab",
			"nctr[_mod]": "pagelet_timeline_app_collection_" + (Context.i_userID || Context.userID) + ":2356318349:2"
		};

		FcaData
			.post(
				"https://www.facebook.com/ajax/profile/removefriendconfirm.php",
				Context.jar,
				form
			)
			.then(utils.parseAndCheckLogin(Context, FcaData))
			.then(function (resData) {
				if (resData.error) {
					throw resData;
				}

				return callback(null, true);
			})
			.catch(function (err) {
				return callback(err);
			});

		return returnPromise;
	};
};
