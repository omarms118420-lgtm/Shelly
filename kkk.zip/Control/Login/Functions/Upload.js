const utils = require('../Funcs.js');


module.exports = function (FcaData, Client, Context) {
	function upload(attachments, callback) {
		callback = callback || function () { };
		const uploads = [];

	
		for (let i = 0; i < attachments.length; i++) {
			if (!utils.isReadableStream(attachments[i])) {
				throw {
					error:
						"Attachment should be a readable stream and not " +
						utils.getType(attachments[i]) +
						"."
				};
			}

			const form = {
				upload_1024: attachments[i],
				voice_clip: "true"
			};

			uploads.push(
				FcaData
					.postFormData(
						"https://upload.facebook.com/ajax/mercury/upload.php",
						Context.jar,
						form,
						{}
					)
					.then(utils.parseAndCheckLogin(Context, FcaData))
					.then(function (resData) {
						if (resData.error) {
							throw resData;
						}

					
						return resData.payload.metadata[0];
					})
			);
		}

			Promise
			.all(uploads)
			.then(function (resData) {
				callback(null, resData);
			})
			.catch(function (err) {
				return callback(err);
			});
	}

	return function uploadAttachment(attachments, callback) {
		if (
			!attachments &&
			!utils.isReadableStream(attachments) &&
			!utils.getType(attachments) === "Array" &&
			(utils.getType(attachments) === "Array" && !attachments.length)
		)
			throw { error: "Please pass an attachment or an array of attachments." };

		let resolveFunc = function () { };
		let rejectFunc = function () { };
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});

		if (!callback) {
			callback = function (err, info) {
				if (err) {
					return rejectFunc(err);
				}
				resolveFunc(info);
			};
		}

		if (utils.getType(attachments) !== "Array")
			attachments = [attachments];

		upload(attachments, (err, info) => {
			if (err) {
				return callback(err);
			}
			callback(null, info);
		});

		return returnPromise;
	};
};