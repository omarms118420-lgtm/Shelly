const utils = require('../Funcs.js');


module.exports = function (FcaData, Client, Context) {
	return function resolvePhotoUrl(photoID, callback) {
		let resolveFunc = function () { };
		let rejectFunc = function () { };
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});

		if (!callback) {
			callback = function (err, friendList) {
				if (err) {
					return rejectFunc(err);
				}
				resolveFunc(friendList);
			};
		}

		FcaData
			.get("https://www.facebook.com/mercury/attachments/photo", Context.jar, {
				photo_id: photoID
			})
			.then(utils.parseAndCheckLogin(Context, FcaData))
			.then(resData => {
				if (resData.error) {
					throw resData;
				}

				const photoUrl = resData.jsmods.require[0][3][0];

				return callback(null, photoUrl);
			})
			.catch(err => {
				return callback(err);
			});

		return returnPromise;
	};
};
