module.exports = {
  Dora: {
    name: "نظام",
    Aliases: ["botsys"],
    Author: "Shady Tarek",
    Role: 3,
    Rest: 5,
    Description: "",
    Class: "ثريدز",
  },

   languages: {
      Ar: {
        GroupOnly: "⚠️ | التحكم بالنظام للمجموعات فقط",
        AlreadyOff: "⚠️ | البوت مطفي اصلا",
        AlreadyOn: "⚠️ | البوت غير مطفي اصلا",
        BotDisabled: "⚠️ | تم إيقاف دورا في هذه المجموعة",
        BotEnabled: "✅ | تم تفعيل دورا بنجاح في هذه المجموعة",
      },
      En: {
        GroupOnly: "⚠️ | System control is for groups only",
        AlreadyOff: "⚠️ | The bot is already turned off",
        AlreadyOn: "⚠️ | The bot is already running",
        BotDisabled: "⚠️ | Dora has been disabled in this group",
        BotEnabled: "✅ | Dora has been successfully enabled in this group",
      },
    },

  Begin: async function ({
    api,
    args,
    event,
    threadsData,
    Message,
    getLang: GetLang,
  }) {
    try {
      if (!event.Group) {
        return Message.reply(GetLang("GroupOnly"));
      }

      const targetID = event.ThreadID;
      const td = await threadsData.get(targetID);

      const cmd = (args[0] || "").toLowerCase();

      if (
        cmd === "ايقاف" ||
        cmd === "اطفاء" ||
        cmd === "off"
      ) {
        if (td.On === false) {
          return Message.reply(GetLang("AlreadyOff"));
        }

        await api.Nickname("❌  Dora ❌", targetID, api.CurrentID());
        await threadsData.set(targetID, { On: false });
        await threadsData.refreshInfo(targetID);

        return Message.reply(GetLang("BotDisabled"));
      }

      if (
        cmd === "تفعيل" ||
        cmd === "on"
      ) {
        if (td.On === true) {
          return Message.reply(GetLang("AlreadyOn"));
        }

        await api.Nickname("✅  Dora  ✅", targetID, api.CurrentID());
        await threadsData.set(targetID, { On: true });
        await threadsData.refreshInfo(targetID);

        return Message.reply(GetLang("BotEnabled"));
      }
    } catch (e) {
      Message.react("❌");
    }
  },
};
