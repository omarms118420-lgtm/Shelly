const axios = require("axios");

module.exports = {
  Dora: {
    name: "حيوان",
    Version: "2",
    Author: "Gry KJ",
    Rest: 10,
    Role: 0,
    Description: "تأثيرات حيوانات أليفة على الصور",
    Class: "صور"
  },

  Begin: async function({ event, args, Message }) {
    try {
       const effectType = args[0]?.toLowerCase() || "pet";
      const validEffects = ["pet", "triggered", "jail", "gay", "wanted"];

      if (!validEffects.includes(effectType)) {
        return Message.reply(
          `❌ تأثير غير صالح!\n\n✅ التأثيرات المتاحة:\n• pet - مخلب حيوان 🐾\n• triggered - غاضب 😡\n• jail - سجن 🔒\n• gay - قوس قزح 🌈\n• wanted - مطلوب 🔍\n\n📝 مثال: حيوان pet @شخص`
        );
      }
       let uid;
      let targetName = "صورتك";

      if (event.Mentions && Object.keys(event.Mentions).length > 0) {
        uid = Object.keys(event.Mentions)[0];
        targetName = event.Mentions[uid].replace("@", "");
      } else if (event.MessageReply) {
        uid = event.MessageReply.SenderID;
        targetName = "صورة الشخص";
      } else {
        uid = event.SenderID;
      }
      const effectMessages = {
        pet: "🐾 تأثير المخلب الأليف",
        triggered: "😡 تأثير الغضب",
        jail: "🔒 تأثير السجن",
        gay: "🌈 تأثير قوس القزح",
        wanted: "🔍 تأثير المطلوب"
      };

      Message.React("⏳");
      await Message.reply(`⏳ جاري تطبيق ${effectMessages[effectType]}...`);

      const avatarURL = `https://graph.facebook.com/${uid}/picture?width=512&height=512&access_token=350685531728|62f8ce9f74b12f84c123cc23437a4a32`;

      const apiEndpoints = {
        pet: `https://api.popcat.xyz/v2/pet?image=${encodeURIComponent(avatarURL)}`,
        triggered: `https://api.popcat.xyz/triggered?image=${encodeURIComponent(avatarURL)}`,
        jail: `https://api.popcat.xyz/jail?image=${encodeURIComponent(avatarURL)}`,
        gay: `https://api.popcat.xyz/gay?image=${encodeURIComponent(avatarURL)}`,
        wanted: `https://api.popcat.xyz/wanted?image=${encodeURIComponent(avatarURL)}`
      };

      const response = await axios.get(apiEndpoints[effectType], {
        responseType: "stream",
      });

      if (!response.data) {
        throw new Error("لم يتم استلام بيانات الصورة");
      }

      Message.React("✅");
      await Message.reply({
        Body: `${effectMessages[effectType]} على ${targetName}!\n\n✨ تم تطبيق التأثير بنجاح\n💕 استمتع بالصورة`,
        Attachment: [response.data]
      });


    } catch (error) {
      console.error("خطأ في التأثير:", error);
      Message.React("❌");
      return Message.reply(
        `❌ حدث خطأ في تطبيق التأثير!\n💬 ${error.message}\n\n💡 حاول مرة أخرى`
      );
    }
  }
};