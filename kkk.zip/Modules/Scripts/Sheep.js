const Jimp = require("jimp");
const fs = require("fs");
const path = require("path");

module.exports = {
  Dora: {
    name: "خروفي",
    Aliases: ["sheep"],
    Version: "1",
    Author: "Gry KJ",
    Rest: 5,
    Role: 0,
    Description: "رد على لبدك تخليه خروفك",
    Class: "ترفية"
  },

  Begin: async function({ event, Message, usersData }) {
    try {
      if (!event.MessageReply && (!event.Mentions || Object.keys(event.Mentions).length === 0)) {
        return Message.reply("⚠️ | رد على حد او منشنه عشان تخليه خروفك");
      }

      const target = event.MessageReply?.SenderID || Object.keys(event.Mentions)[0];

      Message.React("🐑");
      await Message.reply("⏳ | جاري تحويلك وصديقك لخرفان...");

      const background = await Jimp.read("https://i.ibb.co/YThmPKSR/h2-Qh6-Jd-Wqf.jpg");
      const userImg = await Jimp.read(await usersData.getAvatarUrl(event.SenderID));
      const targetImg = await Jimp.read(await usersData.getAvatarUrl(target));

      userImg.resize(190, 190).circle();
      targetImg.resize(190, 190).circle();

      background.composite(userImg, 150, 200);
      background.composite(targetImg, 170, 430);

      const cacheDir = path.join(__dirname, "cache");
      if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir);

      const filePath = path.join(cacheDir, "sheep.jpg");
      await background.writeAsync(filePath);

      const stream = fs.createReadStream(filePath);

      Message.React("✅");
      await Message.reply({
        Body: "🐑 | تم تحويلكم لخرفان بنجاح! 😂",
        Attachment: [stream]
      });

      setTimeout(() => {
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      }, 5000);

    } catch (err) {
      Message.React("❌");
      Message.reply(`❌ | حدث خطأ أثناء التحويل!\n💬 ${err.message}`);
    }
  }
};
