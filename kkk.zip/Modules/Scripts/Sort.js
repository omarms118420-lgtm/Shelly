const fs = require("fs");
const path = require("path");

const WA = fs.readFileSync(
  path.join(__dirname + "/cache/Json/Words.json"),
  "utf-8"
);
const wordsArray = JSON.parse(WA);

module.exports = {
  Dora: {
    name: "ترتيب",
    Author: "Shady Tarek",
    Role: 0,
    Rest: 5,
    Description: "اسرع من يرتب الكلمة يكسب",
    Class: "الألعاب",
  },

  Begin: async function ({ Message }) {
    try {
      const randomWord = getRandomFromArray(wordsArray);
      const shuffledWord = shuffleWord(randomWord);

      await Message.reply({
        Body: `⌯︙رتب : [ ${shuffledWord} ]`,
      });

      global.Dora.Listen.set(Math.floor(Math.random() * 10000), {
        condition: `event.Body.toLowerCase() === "${randomWord.toLowerCase()}"`,
        result: `async () => {
          try {
            Message.react("✅");
            Message.reply(
              "⌯ | " +
                await usersData.getName(event.SenderID) +
                " ، فاز وكان أسرع شخص يرتب الكلمة : ${randomWord} 📕"
            );
            await usersData.addStars(event.SenderID, 1);
          } catch (e) {}
        }`,
      });
    } catch (e) {
      Message.react("❌");
    }
  },
};

function getRandomFromArray(array) {
  return array[Math.floor(Math.random() * array.length)];
}

function shuffleWord(word) {
  return word
    .split("")
    .sort(() => Math.random() - 0.5)
    .join(" ");
}
