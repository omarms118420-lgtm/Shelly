module.exports = {
  Dora: {
    name: "أوامر",
    Aliases: ["اوامر", "الاوامر", "help", "commands", "menu"],
    author: "System",
    Role: 0,
    Rest: 5,
    description: "عرض قائمة جميع الأوامر المتاحة",
    Class: "خدمات"
  },

  languages: {
    Ar: {
      commandsList: "⌔︙اوامــر دورا 🌌\n\n%1"
    }
  },

  Begin: async function ({ Message, getLang }) {
    const { commands } = global.Dora;

    const categories = {};

    for (const [name, command] of commands) {
      if (!command.Dora || !command.Dora.Class) continue;

      const category = command.Dora.Class;

      if (!categories[category]) {
        categories[category] = [];
      }

      categories[category].push(name);
    }

    let text = "";
    const sortedCategories = Object.keys(categories).sort();

    for (const category of sortedCategories) {
      const cmds = categories[category].sort();

      text += `⨳┅━━┉ ${category} ┉━━┅⨳\n`;
      text += `⌯ ${cmds.join(" │ ")}\n\n`;
    }

    const finalMessage = getLang("commandsList", text.trim());

    return Message.reply(finalMessage);
  }
};